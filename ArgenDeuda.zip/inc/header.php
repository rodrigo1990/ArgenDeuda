<header>
	<nav>
		<div id="xsMenu" class="menuXs ">
				<div class="header-xsMenu">
					<i class="fa fa-close w3-large"  style="" id="cerrarMenu"></i>
					<h4 style="">Inicio</h4>
				</div>
		 		<ul>
	 			<li><a href="index.php">Home</a></li>
		 		<li><a href="quienes-somos.php">¿Que es Argenpagos?</a></li>
		 		<li><a href="preguntas-frecuentes.php">Preguntas Frecuentes</a></li>
		 		<li><a href="quiero-pagar.php">Quiero Pagar</a></li>
		 		<li><a href="contacto.php">Contacto</a></li>
		 		
			
				</ul>
		</div>

		<div class="container-fluid menu">
			<div class="row">
				<div class="col-sm-9 col-xs-9 col-md-3 col-lg-3 logo-cont">
					<a href="index.php"><img src="img/logo.png" class="img-responsive" alt=""></a>
				</div>
				<div class="hidden-xs hidden-sm col-md-9 col-lg-9">
					<ul>
						<li>
							<a href="quienes-somos.php">¿QUE ES ARGENPAGOS?</a>
						</li>
						<li>
							<a href="preguntas-frecuentes.php">PREGUNTAS FRECUENTES</a>
						</li>
						<li>
							<a href="quiero-pagar.php">QUIERO PAGAR</a>
						</li>
						<li>
							<a href="contacto.php">CONTACTO</a>
						</li>
					</ul>
				</div>
				<div class="hidden-lg hidden-md col-sm-3 col-xs-3 text-center " style="padding: 5%;">
					<i class="fa fa-bars"  id="abrirMenu"></i>
				</div>
			</div>
		</div>

	</nav>
</header>

