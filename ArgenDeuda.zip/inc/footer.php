<footer>
	<div class="row">
		<div class="container">
			<div class="col-sm-4">
				<h4>
					CONTACTO
				</h4>
				<p>
					Consultanos al 0800-345-2733
				</p>
				<p>
					SMS o Whatsapp al +54 11-5053-7033
				</p>
			</div>
			<div class="col-sm-4">
				<h4>
					HORARIO DE ATENCIÓN
				</h4>
				<p>
					Lunes a Viernes de 9 a 18hs.
				</p>
				<p>
					Sábados de 9 a 13 hs.
				</p>
			</div>
			<div class="col-sm-4">
				<h4>
					TERMINOS DE LEGALES 
				</h4>
				<p>
					<a href="terminos.pdf">Conoce los términos legales.</a>
				</p>
			</div>
		</div>
	</div>


</footer>