$(document).ready(function(){
	$(".margin-to-header").css("margin-top",$("header").height());
	
});
