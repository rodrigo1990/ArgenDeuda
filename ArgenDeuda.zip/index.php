<?php include("inc/head.php") ?>
</head>
<body>
<?php include("inc/header.php") ?>
	
	
<div class="container-fluid slider-cont">
	
	
		<div class="row  margin-to-header">
			<!-- <div id="jssor_1" style="position:relative;margin:0 auto;top:0px;left:0px;width:980px;height:380px;overflow:hidden;visibility:hidden;">
        <div data-u="loading" class="jssorl-004-double-tail-spin" style="position:absolute;top:0px;left:0px;text-align:center;background-color:rgba(0,0,0,0.7);">
            <img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="img/double-tail-spin.svg" />
        </div>
        <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:980px;height:380px;overflow:hidden;">
            <div>
                <img data-u="image" src="img/argenpesos_2018_deuda_web-18.png" />
                <img style="position:absolute;top:-48px;left:1008px;width:90px;height:90px;max-width:90px;" src="img/argenpesos_2018_deuda_web-15.png" />
                <img data-u="caption" data-t="0" style="position:absolute;top:-108px;left:860px;width:107px;height:74px;max-width:107px;" src="img/argenpesos_2018_deuda_web-08.png" />
                <img data-u="caption" data-t="1" style="position:absolute;top:-163px;left:725px;width:104px;height:113px;max-width:104px;" src="img/argenpesos_2018_deuda_web-11.png" />
                <img data-u="caption" data-t="2" style="position:absolute;top:-94px;left:486px;width:53px;height:73px;max-width:53px;" src="img/argenpesos_2018_deuda_web-10.png" />
                <img data-u="caption" data-t="3" style="position:absolute;top:-126px;left:582px;width:108px;height:120px;max-width:108px;" src="img/argenpesos_2018_deuda_web-09.png" />
                <img data-u="caption" data-t="4" style="position:absolute;top:-89px;left:719px;width:78px;height:69px;max-width:78px;" src="img/argenpesos_2018_deuda_web-12.png" />
                <img data-u="caption" data-t="5" style="position:absolute;top:-98px;left:362px;width:94px;height:81px;max-width:94px;" src="img/argenpesos_2018_deuda_web-13.png" />
                <img data-u="caption" data-t="6" style="position:absolute;top:-23px;left:-478px;width:409px;height:311px;max-width:409px;" src="img/argenpesos_2018_deuda_web-17.png" />
                <img data-u="caption" data-t="7" style="position:absolute;top:-409px;left:15px;width:348px;height:239px;max-width:348px;" src="img/argenpesos_2018_deuda_web-08.png" />
                <img data-u="caption" data-t="8" style="position:absolute;top:-576px;left:193px;width:547px;height:592px;max-width:547px;" src="img/argenpesos_2018_deuda_web-11.png" />
                <img data-u="caption" data-t="9" style="position:absolute;top:-337px;left:714px;width:269px;height:368px;max-width:269px;" src="img/argenpesos_2018_deuda_web-10.png" />
                <img data-u="caption" data-t="10" style="position:absolute;top:-516px;left:-277px;width:547px;height:592px;max-width:547px;" src="img/argenpesos_2018_deuda_web-11.png" />
            </div>
            <div>
                <img data-u="image" src="img/argenpesos_2018_deuda_web-18.png" />
                <img data-u="caption" data-t="11" style="position:absolute;top:-69px;left:-835px;width:763px;height:377px;max-width:763px;" src="img/nube-19.png" />
                <img data-u="caption" data-t="12" style="position:absolute;top:-79px;left:1019px;width:616px;height:487px;max-width:616px;" src="img/nube-20.png" />
                <img data-u="caption" data-t="13" style="position:absolute;top:-856px;left:-92px;width:1139px;height:901px;max-width:1139px;" src="img/nube-20.png" />
                <img data-u="caption" data-t="14" style="position:absolute;top:396px;left:230px;width:478px;height:364px;max-width:478px;" src="img/argenpesos_2018_deuda_web-17.png" />
            </div>
        </div>
        <div data-u="navigator" class="jssorb051" style="position:absolute;bottom:12px;right:12px;" data-autocenter="1" data-scale="0.5" data-scale-bottom="0.75">
            <div data-u="prototype" class="i" style="width:16px;height:16px;">
                <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                    <circle class="b" cx="8000" cy="8000" r="5800"></circle>
                </svg>
            </div>
        </div>
        <div data-u="arrowleft" class="jssora051" style="width:55px;height:55px;top:0px;left:25px;" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <polyline class="a" points="11040,1920 4960,8000 11040,14080 "></polyline>
            </svg>
        </div>
        <div data-u="arrowright" class="jssora051" style="width:55px;height:55px;top:0px;right:25px;" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <polyline class="a" points="4960,1920 11040,8000 4960,14080 "></polyline>
            </svg>
        </div>
    </div> -->
			 <div class="owl-one owl-carousel owl-theme">
				<div>
					<div class="slide">
						<a href="quiero-pagar.php">
							<img src="img/banner/banner1.jpg" alt="">
						</a>
					</div>
				</div>
				<div>
					<div class="slide">
						<a href="quiero-pagar.php">
							<img src="img/banner/banner1.jpg" alt="">
						</a>
					</div>
				</div>
				<div>
					<div class="slide">
						<a href="quiero-pagar.php">
							<img src="img/banner/banner1.jpg" alt="">
						</a>
					</div>
				</div>
			</div>
		</div>

	


</div>

	



<div class="container text-center ">
		<div class="row">
			<iframe src="quiero-pagar-components/quiero-pagar-form.php" id="iFrame" frameborder="0" style="width:100%;height: 452px;overflow: hidden;"></iframe>
		</div>
</div>




<section id="index">
	<div class="container">
	

		<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
			<h2>DEUDORES</h2>
			<p>
				Con Argen Pagos obtenés los mejores planes de pago y podés deshacerte de tus deudas de manera <b>fácil, rápida y transparente</b>. Nuestros clientes son policias, retirados, docentes, Ministerios de Salud de Buenos Aires, entre otros. Nos contratan con el fin de que te ofrezcamos la mejor alternativa para cancelar tu deuda.
			</p>
			<br>
			<p><span><b>Contacte con nuestros especialistas que esucharán tu situación personal y te ayudarán con el pago</b></span>.</p>

			<a class="btn" href="contacto.php">CONTACTAR</a>

		</div>

		<div class="hidden-xs hidden-sm col-md-6 col-lg-6 img-cont">
			<img src="img/figura3.png" alt="" width=130% class="img-lg img-responsive">
		</div>

		<div class="col-xs-12 col-sm-12 hidden-md hidden-lg img-cont">
			<img src="img/figura3.png" alt="" width=80% class="img-lg">
		</div>


	</div>
	<div clasS="flex-cont">
		<div class="container">
			<div class="row">
				<ul class="flex">
					<li>
						<div class="overlap">
							<img src="img/1.png" alt="">
							<h4>ALTERNATIVAS DE PAGO</h4>
							<p>
								Te informamos sobre los tres tipos de <br> alternativas para cancelar tu deuda <br> actualizada.
							</p>

							<a class="btn" href="">VER MAS +</a>
						</div>
					</li>
					<li>
						<div class="overlap">
							<img src="img/2.png" alt="">
							<h4>MEDIOS DE PAGO</h4>
							<p>
								Te mostramos los servicios con los que <br> contás para abonar tu deuda <br> actualizada.
							</p>
							<a class="btn" href="">VER MAS +</a>
						</div>
						
					</li>
					<li>
						<div class="overlap">
							<img src="img/3.png" alt="">
							<h4>DOCUMENTACIÓN</h4>
							<p>
								Te explicamos qué debes firmar y qué <br> comprobantes de pago obtenés <br> al suscribir un plan de pagos.
							</p>
							<a href="" class="btn">VER MAS +</a>
						</div>
					</li>
					<li>
						<div class="overlap">
							<img src="img/4.png" alt="">
							<h4>TUS DERECHOS</h4>
							<p>
								Te mostramos los servicios con los que <br> contás para abonar tu deuda <br> actualizada.
							</p>
							<a href="" class="btn">VER MAS +</a>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row metodos-pago">
			
			<div class="col-xs-12 col-sm-12 col-md-9 col-lg-7">
				<h2 class="metodos-title">MÉTODOS DE PAGO</h2>
				<ul class="metodos-list">
					<li><img src="img/metodos_pago/1.png" alt="" class="img-width"></li>
					<li><img src="img/metodos_pago/2.png" alt=""></li>
					<li><img src="img/metodos_pago/3.png" alt=""></li>
					<li><img src="img/metodos_pago/4.png" alt=""></li>
					<li><img src="img/metodos_pago/5.png" alt=""></li>
					<li><img src="img/metodos_pago/6.png" alt="" class="img-width"></li>
				</ul>
			</div>	
			<div class="col-xs-12 col-sm-12 col-md-3 col-lg-5">
				<h2 class="metodos-title">TARJETAS DE CRÉDITO</h2>
				<ul class="metodos-list">
					<li><img src="img/metodos_pago/7.png" alt="" class="img-width"></li>
					<li><img src="img/metodos_pago/8.png" alt="" class="img-width"></li>
					<li><img src="img/metodos_pago/9.png" alt="" class="img-width"></li>
				</ul>
			</div>	

		</div>
	</div>




</section>




	


<?php include("inc/footer.php") ?>

<?php include("inc/scripts.php")?>
<!--  <script type="text/javascript" src="lluviaBilletes/makeItRain.js"></script>-->
<script type="text/javascript" src="OwlCarousel2-2.3.4/dist/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/slider.js"></script>

<!--  <script src="js/jssor.slider-27.5.0.min.js" type="text/javascript"></script>-->
<!-- <script src="js/jssor_1_slider_init.js" type="text/javascript"></script>
<script type="text/javascript">//jssor_1_slider_init();</script> -->
   

</body>
</html>