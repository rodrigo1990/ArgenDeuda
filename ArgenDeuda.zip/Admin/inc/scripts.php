<script type="text/javascript" src="js/JQuery.min.js"></script>
<script type="text/javascript" src="js/login.js"></script>