<?php include("inc/head.php") ?>
</head>
<?php include("inc/header.php") ?>

	<div class="container-fluid img-section-cont">	
		<div class="row img-section margin-to-header">
			<div>

			<img src="img/img-seccion-quiero-pagar.jpg" alt="">
			</div>
		</div>
	</div>

<section id="quiero-pagar">
	<div class="container text-center ">
		<div class="row">
			<iframe src="quiero-pagar-components/quiero-pagar-form.php" id="iFrame" frameborder="0" style="width:100%;height: 800px;"></iframe>
		</div>


	</div>

<div id="post"></div>
</section>



	


<?php include("inc/footer.php") ?>
<script type="text/javascript" src="js/ConsultarUsuarioProductosAJAX.js"></script>
<?php include("inc/scripts.php")?>
</body>
</html>

