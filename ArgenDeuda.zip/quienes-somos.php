<?php include("inc/head.php") ?>
</head>
<?php include("inc/header.php") ?>

	<div class="container-fluid img-section-cont">
		
		<div class="row img-section margin-to-header padding-bottom">
			<div>

			<img src="img/img-seccion-quienes-somos.jpg" alt="">
			</div>
		</div>


	</div>

<section id="quienes-somos">

	<div class="container ">
		<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 ">
			<h1>ARGEN PAGOS</h1>
			<p>
				Con Argen Pagos obtenés los mejores planes de pago y podés deshacerte de tus deudas de manera <b>fácil, rápida y transparente</b>. 
			</p>
			<p><span><b>Contacte con nuestros asesores que analizarán tu situacion personal y te ayudarán con el pago de tus cuotas.</b></span></p>

			<a class="btn" href="quiero-pagar.php">BUSCAR DEUDAS ARGENPESOS <br> <span>A MI NOMBRE</span></a>

		</div>
		<div class="hidden-xs hidden-sm col-md-6 col-lg-6 text-center	 ">
			<img src="img/figura-qs.png" alt="" width=80% class="img-lg">
		</div>

		


	</div>

</section>




	


<?php include("inc/footer.php") ?>
<?php include("inc/scripts.php")?>
</body>
</html>